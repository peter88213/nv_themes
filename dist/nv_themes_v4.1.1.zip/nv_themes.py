"""A 'Theme Changer' plugin for novelibre.

Version 4.1.1

Adds a 'Theme Changer' entry to the 'Tools' menu to open a window
with a combobox that lists all available themes. 
The selected theme will be persistently applied.  

To have a wider choice, you may want to install the ttkthemes package:

pip install ttkthemes

Requires Python 3.6+
Copyright (c) 2024 Peter Triesberger
For further information see https://github.com/peter88213/nv_themes
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import gettext
import locale
import os
import sys

from abc import ABC, abstractmethod


class PluginBase(ABC):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

    @abstractmethod
    def install(self, model, view, controller, prefs=None):
        pass

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_quit(self):
        pass

    def open_node(self):
        pass

    def unlock(self):
        pass

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation('nv_themes', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message

from tkinter import ttk

import tkinter as tk
from tkinter import ttk


class LabelCombo(ttk.Frame):

    def __init__(self, parent, text, textvariable, values, lblWidth=10):
        super().__init__(parent)
        self.pack(fill='x')
        self._label = ttk.Label(self, text=text, anchor='w', width=lblWidth)
        self._label.pack(side='left')
        self.combo = ttk.Combobox(self, textvariable=textvariable, values=values)
        self.combo.pack(side='left', fill='x', expand=True)

    def current(self):
        return self.combo.current()

    def config(self, **kwargs):
        self.configure(**kwargs)

    def configure(self, text=None, values=None, state=None):
        if text is not None:
            self._label['text'] = text
        if values is not None:
            self.combo['values'] = values
        if state is not None:
            self.combo.config(state=state)


class SettingsWindow(tk.Toplevel):

    def __init__(self, view, prefs, extraThemes, size, **kw):
        self._ui = view
        self._prefs = prefs
        self._extraThemes = extraThemes
        super().__init__(**kw)
        self.title(_('Theme Changer'))
        self.geometry(size)
        self.grab_set()
        self.focus()
        window = ttk.Frame(self)
        window.pack(fill='both')

        theme = self._ui.guiStyle.theme_use()
        themeList = list(self._ui.guiStyle.theme_names())
        themeList.sort()
        self._theme = tk.StringVar(value=theme)
        self._theme.trace('w', self._change_theme)
        themeCombobox = LabelCombo(
            window,
            text=_('GUI Theme'),
            textvariable=self._theme,
            values=themeList,
            lblWidth=20
            )
        themeCombobox.pack(padx=5, pady=5)

        ttk.Button(window, text=_('Close'), command=self.destroy).pack(side='right', padx=5, pady=5)

    def _change_theme(self, *args, **kwargs):
        theme = self._theme.get()
        self._prefs['gui_theme'] = theme
        if self._extraThemes:
            self._ui.guiStyle.set_theme(self._prefs['gui_theme'])
        else:
            self._ui.guiStyle.theme_use(self._prefs['gui_theme'])


try:
    from ttkthemes import ThemedStyle
    extraThemes = True
except ModuleNotFoundError:
    extraThemes = False


class Plugin(PluginBase):
    VERSION = '4.1.1'
    API_VERSION = '4.3'
    DESCRIPTION = 'Allows changing between available themes'
    URL = 'https://github.com/peter88213/nv_themes'

    def install(self, model, view, controller, prefs=None):
        """Add a submenu to the 'Tools' menu.
        
        Positional arguments:
            model -- reference to the main model instance of the application.
            view -- reference to the main view instance of the application.
            controller -- reference to the main controller instance of the application.

        Optional arguments:
            prefs -- deprecated. Please use controller.get_preferences() instead.
        
        Overrides the superclass method.
        """
        prefs = controller.get_preferences()
        __, x, y = view.root.geometry().split('+')
        offset = 300
        windowGeometry = f'+{int(x)+offset}+{int(y)+offset}'
        if extraThemes:
            view.guiStyle = ThemedStyle(view.root)
        if not prefs.get('gui_theme', ''):
            prefs['gui_theme'] = view.guiStyle.theme_use()

        if not prefs['gui_theme'] in view.guiStyle.theme_names():
            prefs['gui_theme'] = view.guiStyle.theme_use()
        if extraThemes:
            view.guiStyle.set_theme(prefs['gui_theme'])
        else:
            view.guiStyle.theme_use(prefs['gui_theme'])

        view.viewMenu.insert_command(
            _('Options'),
            label=_('Change theme'),
            command=lambda: SettingsWindow(view, prefs, extraThemes, windowGeometry)
            )
        view.viewMenu.insert_separator(_('Options'))


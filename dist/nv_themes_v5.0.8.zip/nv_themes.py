"""A 'Theme Changer' plugin for novelibre.

Version 5.0.8

Adds a 'Theme Changer' entry to the 'Tools' menu to open a window
with a combobox that lists all available themes. 
The selected theme will be persistently applied.  

To have a wider choice, you may want to install the ttkthemes package:

pip install ttkthemes

Requires Python 3.7+
Copyright (c) 2025 Peter Triesberger
For further information see https://github.com/peter88213/nv_themes
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import os
import sys
import locale
import gettext

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation(
        'nv_themes',
        LOCALE_PATH,
        languages=[CURRENT_LANGUAGE],
    )
    _ = t.gettext
except:

    def _(message):
        return message

from abc import ABC, abstractmethod
from pathlib import Path



class SubController:

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_open(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass

import tkinter as tk


class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

    @abstractmethod
    def install(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def uninstall(self):
        pass

    def _get_icon(self, fileName):
        if self._ctrl.get_preferences().get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
            icon = tk.PhotoImage(file=f'{iconPath}/{fileName}')
        except:
            icon = None
        return icon
from tkinter import ttk

from abc import abstractmethod



class ModalDialog(tk.Toplevel):
    OFFSET = 300

    @abstractmethod
    def __init__(self, ui, **kw):
        tk.Toplevel.__init__(self, **kw)
        __, x, y = ui.root.geometry().split('+')
        windowGeometry = f'+{int(x)+self.OFFSET}+{int(y)+self.OFFSET}'
        self.geometry(windowGeometry)
        self.grab_set()
        self.focus()
        self.attributes('-topmost', 'true')



class ThemesDialog(ModalDialog):

    def __init__(self, view, prefs, extraThemes, **kw):
        super().__init__(view, **kw)

        self.title(_('Theme Changer'))
        window = ttk.Frame(self)
        window.pack(fill='both')


        def change_theme(event):
            theme = themeVar.get()
            prefs['gui_theme'] = theme
            try:
                if extraThemes:
                    view.guiStyle.set_theme(prefs['gui_theme'])
                else:
                    view.guiStyle.theme_use(prefs['gui_theme'])
            except:
                pass

        themeFrame = ttk.Frame(window)
        themeFrame.pack(fill='x', expand=True, pady=2)
        ttk.Label(
            themeFrame,
            text=_('GUI Theme'),
            anchor='w',
            width=20,
        ).pack(side='left')

        theme = view.guiStyle.theme_use()
        themeList = list(view.guiStyle.theme_names())
        themeList.sort()
        themeVar = tk.StringVar(value=theme)
        themeCombobox = ttk.Combobox(
            themeFrame,
            textvariable=themeVar,
            values=themeList,
        )
        themeCombobox.pack(padx=5, pady=5)
        themeCombobox.bind('<<ComboboxSelected>>', change_theme)

        ttk.Button(
            window, text=_('Close'),
            command=self.destroy,
        ).pack(side='right', padx=5, pady=5)


try:
    from ttkthemes import ThemedStyle
    extraThemes = True
except ModuleNotFoundError:
    extraThemes = False


class Plugin(PluginBase):
    VERSION = '5.0.8'
    API_VERSION = '5.0'
    DESCRIPTION = 'Allows changing between available themes'
    URL = 'https://github.com/peter88213/nv_themes'

    def install(self, model, view, controller):
        """Add a submenu to the 'Tools' menu.
        
        Positional arguments:
            model -- reference to the novelibre main model instance.
            view -- reference to the novelibre main view instance.
            controller -- reference to the novelibre main controller instance.

        Extends the superclass method.
        """
        super().install(model, view, controller)
        self.prefs = self._ctrl.get_preferences()

        if extraThemes:
            view.guiStyle = ThemedStyle(view.root)
        if not self.prefs.get('gui_theme', ''):
            self.prefs['gui_theme'] = view.guiStyle.theme_use()
        if not self.prefs['gui_theme'] in view.guiStyle.theme_names():
            self.prefs['gui_theme'] = view.guiStyle.theme_use()
        if extraThemes:
            view.guiStyle.set_theme(self.prefs['gui_theme'])
        else:
            view.guiStyle.theme_use(self.prefs['gui_theme'])


        label = _('Change theme')
        view.viewMenu.insert_command(
            _('Options'),
            label=label,
            command=self.start_dialog,
        )
        view.viewMenu.insert_separator(_('Options'))

    def start_dialog(self):
        ThemesDialog(
            self._ui,
            self.prefs,
            extraThemes,
        )

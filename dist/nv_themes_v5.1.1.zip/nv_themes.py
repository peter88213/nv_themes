"""A 'Theme Changer' plugin for novelibre.

Version 5.1.1

Adds a 'Theme Changer' entry to the 'Tools' menu to open a window
with a combobox that lists all available themes. 
The selected theme will be persistently applied.  

To have a wider choice, you may want to install the ttkthemes package:

pip install ttkthemes

Requires Python 3.7+
Copyright (c) 2024-2026 Peter Triesberger
For further information see https://github.com/peter88213/nv_themes
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import os
import sys
import locale
import gettext

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation(
        'nv_themes',
        LOCALE_PATH,
        languages=[CURRENT_LANGUAGE],
    )
    _ = t.gettext
except:

    def _(message):
        return message

from abc import ABC, abstractmethod
from pathlib import Path



class SubController:

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_open(self):
        pass

    def on_quit(self):
        pass

    def ready_to_close(self):
        return True

    def unlock(self):
        pass

import tkinter as tk


class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''
    HELP_SITE = None
    HELP_PAGE = None

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

        self._icon = None

    @abstractmethod
    def install(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def uninstall(self):
        pass

    def _add_help_menu_entry(self, label):

        def open_help():
            self._ctrl.open_help(
                page=self.HELP_PAGE,
                site=self.HELP_SITE
            )

        self._ui.helpMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            command=open_help,
        )

    def _get_icon(self, fileName):
        if self._ctrl.get_preferences().get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
            icon = tk.PhotoImage(file=f'{iconPath}/{fileName}')
        except:
            icon = None
        return icon

DEFAULT_COLORS = dict(
    color_1st_edit='#8b6508',  # DarkGoldenrod4
    color_2nd_edit='#cd950c',  # DarkGoldenrod3
    color_before_schedule='#32cd32',  # lime green
    color_behind_schedule='#ff00ff',  # magenta
    color_chapter='#008b00',  # green4
    color_comment_tag='#fffacd',  # lemon chiffon
    color_done='#eead0e',  # DarkGoldenrod2
    color_draft='#000000',  # black
    color_highlight='#e6e6fa',  # lavender
    color_inactive_bg='#d3d3d3',  # light gray
    color_locked_bg='#696969',  # dim gray
    color_locked_fg='#d3d3d3',  # light gray
    color_modified_bg='#ffc125',  # goldenrod1
    color_modified_fg='#b03060',  # maroon
    color_notes_bg='#fffacd',  # lemon chiffon
    color_notes_fg='#000000',  # black
    color_note_tag='#ffe4c4',  # bisque
    color_on_schedule='#000000',  # black
    color_outline='#9932cc',  # dark orchid
    color_separator='#d3d3d3',  # light gray
    color_stage='#ff0000',  # red
    color_status_error_bg='#ff0000',  # red
    color_status_error_fg='#ffffff',  # white
    color_status_notification_bg='#ffff00',  # yellow
    color_status_notification_fg='#000000',  # black
    color_status_success_bg='#008b00',  # green4
    color_status_success_fg='#ffffff',  # white
    color_text_bg='#ffffff',  # white
    color_text_fg='#000000',  # black
    color_unused='#808080',
    color_xml_tag='#6495ed',  # cornflower blue
)
from tkinter import ttk

from abc import abstractmethod
import platform



class ModalDialog(tk.Toplevel):
    OFFSET = 300
    RESIZABLE = False

    @abstractmethod
    def __init__(self, ui, **kw):
        tk.Toplevel.__init__(self, **kw)
        __, x, y = ui.root.geometry().split('+')
        windowGeometry = f'+{int(x)+self.OFFSET}+{int(y)+self.OFFSET}'
        self.geometry(windowGeometry)
        if not self.RESIZABLE:
            self.withdraw()

            self.wm_resizable(False, False)
            if platform.system() == 'Windows':
                self.attributes('-toolwindow', True)
            self.update()
            self.deiconify()
        self.wait_visibility()
        self.grab_set()
        self.focus()
        self.wm_attributes('-topmost', True)

from tkinter import messagebox



class DarkMode:

    COLORS = dict(
        color_1st_edit='#eead0e',  # DarkGoldenrod2
        color_2nd_edit='#cd950c',  # DarkGoldenrod3
        color_before_schedule='#2e8b57',  # sea green
        color_behind_schedule='#ff6347',  # tomato
        color_chapter='#7fff00',  # chartreuse
        color_comment_tag='#8b7e66',  # wheat4
        color_done='#8b6508',  # DarkGoldenrod4
        color_draft='#ffffff',  # white
        color_highlight='#2f4f4f',  # dark slate gray
        color_inactive_bg='#394341',
        color_locked_bg='#696969',  # dim gray
        color_locked_fg='#d3d3d3',  # light gray
        color_modified_bg='#ffc125',  # goldenrod1
        color_modified_fg='#b03060',  # maroon
        color_notes_bg='#8b7e66',  # wheat4
        color_notes_fg='#ffffff',  # white
        color_on_schedule='#ffffff',  # white
        color_outline='#ee7ae9',  # orchid2
        color_separator='#000000',  # black
        color_stage='#ff6347',  # tomato
        color_status_error_bg='#ff0000',  # red
        color_status_error_fg='#ffffff',  # white
        color_status_notification_bg='#ffff00',  # yellow
        color_status_notification_fg='#000000',  # black
        color_status_success_bg='#008b00',  # green4
        color_status_success_fg='#ffffff',  # white
        color_text_bg='#424242',
        color_text_fg='#d3d3d3',  # light gray
        color_unused='#808080',
        color_xml_tag='#6495ed',  # cornflower blue
    )

    @classmethod
    def set_colors(cls, prefs):
        colorsChanged = False
        for color in cls.COLORS:
            if prefs.get(
                color,
                cls.COLORS[color]
            ) != cls.COLORS[color]:
                prefs[color] = cls.COLORS[color]
                colorsChanged = True
        if colorsChanged:
            cls._show_message(_('Dark mode selected'))

    @classmethod
    def reset_colors(cls, prefs):
        colorsChanged = False
        for color in cls.COLORS:
            if prefs.get(
                color,
                DEFAULT_COLORS[color]
            ) != DEFAULT_COLORS[color]:
                prefs[color] = DEFAULT_COLORS[color]
                colorsChanged = True
        if colorsChanged:
            cls._show_message(_('Bright mode selected'))

    @classmethod
    def _show_message(cls, detail):
        messagebox.showinfo(
            title=_('Theme changed'),
            message=_('Please restart novelibre now to apply changed colors'),
            detail=detail,
        )


class ThemesDialog(ModalDialog):

    DARK_THEMES = (
        'black',
        'equilux',
    )

    def __init__(self, view, prefs, ttkThemesAvailable, **kw):
        super().__init__(view, **kw)

        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self._prefs = prefs
        self.title(_('Theme Changer'))


        def change_theme(event):
            theme = self._themeVar.get()
            prefs['gui_theme'] = theme
            try:
                if ttkThemesAvailable:
                    view.guiStyle.set_theme(prefs['gui_theme'])
                else:
                    view.guiStyle.theme_use(prefs['gui_theme'])
            except:
                pass

        themeFrame = ttk.Frame(self)
        themeFrame.pack(fill='x', expand=True, pady=2)
        ttk.Label(
            themeFrame,
            text=_('GUI Theme'),
            anchor='w',
            width=20,
        ).pack(
            side='left',
            padx=5,
        )

        currentTheme = view.guiStyle.theme_use()
        themeList = list(view.guiStyle.theme_names())
        themeList.sort()
        self._themeVar = tk.StringVar(value=currentTheme)
        themeCombobox = ttk.Combobox(
            themeFrame,
            textvariable=self._themeVar,
            values=themeList,
        )
        themeCombobox.pack(padx=5, pady=5)
        themeCombobox.bind('<<ComboboxSelected>>', change_theme)

        footer = tk.Frame(self)
        footer.pack(fill='both')

        ttk.Button(
            footer,
            text=_('Close'),
            command=self._on_close,
        ).pack(side='right', padx=5, pady=5)

    def _on_close(self, event=None):
        if self._themeVar.get() in self.DARK_THEMES:
            DarkMode.set_colors(self._prefs)
        else:
            DarkMode.reset_colors(self._prefs)
        self.destroy()


try:
    from ttkthemes import ThemedStyle
except ModuleNotFoundError:
    ttkThemesAvailable = False
else:
    ttkThemesAvailable = True


class Plugin(PluginBase):
    VERSION = '5.1.1'
    API_VERSION = '5.67'
    DESCRIPTION = 'Allows changing between available themes'
    URL = 'https://github.com/peter88213/nv_themes'

    def install(self, model, view, controller):
        """Install the plugin at runtime.
        
        Positional arguments:
            model -- reference to the novelibre main model instance.
            view -- reference to the novelibre main view instance.
            controller -- reference to the novelibre main controller instance.

        Extends the superclass method.
        """
        super().install(model, view, controller)
        self.prefs = self._ctrl.get_preferences()

        if ttkThemesAvailable:
            view.guiStyle = ThemedStyle(view.root)
        if not self.prefs.get('gui_theme', ''):
            self.prefs['gui_theme'] = view.guiStyle.theme_use()
        if not self.prefs['gui_theme'] in view.guiStyle.theme_names():
            self.prefs['gui_theme'] = view.guiStyle.theme_use()
        if ttkThemesAvailable:
            view.guiStyle.set_theme(self.prefs['gui_theme'])
        else:
            view.guiStyle.theme_use(self.prefs['gui_theme'])


        def start_dialog():
            ThemesDialog(
                self._ui,
                self.prefs,
                ttkThemesAvailable,
            )

        label = _('Change theme')
        view.viewMenu.insert_command(
            _('Options'),
            label=label,
            command=start_dialog,
        )
        view.viewMenu.insert_separator(_('Options'))

    def uninstall(self):
        prefs = self._ctrl.get_preferences()
        for color in DEFAULT_COLORS:
            prefs[color] = DEFAULT_COLORS[color]

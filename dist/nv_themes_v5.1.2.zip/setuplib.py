"""nv_themes installer library module. 

Version 5.1.2

Copyright (c) 2024-2026 Peter Triesberger
For further information see https://github.com/peter88213/nv_themes
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)
"""
import os
from pathlib import Path
from shutil import copy2
from shutil import copytree
import shutil
import sys
from tkinter import messagebox
import zipfile

PLUGIN = 'nv_themes.py'
VERSION = '5.1.2'

pyz = os.path.dirname(__file__)


def extract_file(sourceFile, targetDir):
    with zipfile.ZipFile(pyz) as z:
        z.extract(sourceFile, targetDir)


def extract_tree(sourceDir, targetDir):
    with zipfile.ZipFile(pyz) as z:
        for file in z.namelist():
            if file.startswith(f'{sourceDir}/'):
                z.extract(file, targetDir)


def cp_tree(sourceDir, targetDir):
    copytree(sourceDir, f'{targetDir}/{sourceDir}', dirs_exist_ok=True)


def handle_incompatible_plugins(applicationDir, pluginDir):
    # Uninstall nv_dark, if any.
    nvDarkPlugin = f'{pluginDir}/nv_dark.py'
    if os.path.isfile(nvDarkPlugin):
        if not messagebox.askokcancel(
            title='nv_themes setup',
            message='Incompatible plugin detected',
            detail='The "nv_dark" plugin will now be uninstalled.',
        ):
            sys.exit()

        print('Removing the nv_dark plugin ...')
        os.remove(nvDarkPlugin)
        print('Removing the awthemes package ...')
        shutil.rmtree(
            f'{applicationDir}/themes/awthemes',
            ignore_errors=True
        )
        print('Restoring the novelibre default colors ...')
        configFile = f'{applicationDir}/config/novx.ini'
        with open(configFile, 'r', encoding='utf-8') as f:
            lines = f.read().split('\n')
        newlines = []
        for line in lines:
            if not line.startswith('color_') and not line.startswith('gui_theme'):
                newlines.append(line)
        with open(configFile, 'w', encoding='utf-8') as f:
            f.write('\n'.join(newlines))
        print('Default colors successfully restored.')


def install(zipped):
    if zipped:
        copy_file = extract_file
        copy_tree = extract_tree
    else:
        copy_file = copy2
        copy_tree = cp_tree

    scriptPath = os.path.abspath(sys.argv[0])
    scriptDir = os.path.dirname(scriptPath)
    os.chdir(scriptDir)

    print(f'*** Installing {PLUGIN} {VERSION} ***\n')
    homePath = str(Path.home()).replace('\\', '/')
    applicationDir = f'{homePath}/.novx'
    if os.path.isdir(applicationDir):
        pluginDir = f'{applicationDir}/plugin'
        handle_incompatible_plugins(applicationDir, pluginDir)
        os.makedirs(pluginDir, exist_ok=True)

        # Install the plugin.
        print(f'Copying "{PLUGIN}" ...')
        copy_file(PLUGIN, pluginDir)

        # Install the localization files.
        print(f'Copying locale ...')
        copy_tree('locale', applicationDir)

        # Install utility.
        copy_file('restore_default_colors.py', applicationDir)

        # Show a success message.
        print(
            f'\nSucessfully installed {PLUGIN} '
            f'at "{os.path.normpath(pluginDir)}".'
        )
    else:
        print(
            'ERROR: Cannot find a novelibre installation '
            f'at "{os.path.normpath(applicationDir)}".'
        )

    # Check, whether the ttkthemes package is available.
    try:
        from ttkthemes import ThemedStyle
    except ModuleNotFoundError:
        print('\nTo have a wider choice, you may want to install the ttkthemes package.\n')

    input('Press ENTER to quit.')


def main(zipped=True):
    try:
        install(zipped)
    except Exception as ex:
        print(str(ex))
        input('Press ENTER to quit.')

